package settings;

/**
 * base clas for board
 * @author dim
 *
 */
public class Board {
	
	// two dimensional array of fields
	protected int [][] fields;
	
	public int[][] getFields(){
		
		return fields;
	}
}
