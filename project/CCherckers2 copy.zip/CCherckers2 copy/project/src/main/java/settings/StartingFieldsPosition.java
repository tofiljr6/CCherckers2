package settings;

public enum StartingFieldsPosition {

	TOP,
	UPPER_RIGHT,
	BOTTOM_RIGHT,
	BOTTOM,
	BOTTOM_LEFT,
	UPPER_LEFT;
}
