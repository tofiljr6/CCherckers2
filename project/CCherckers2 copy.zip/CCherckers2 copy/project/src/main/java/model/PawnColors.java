package model;
/**
 * 
 * enum which defines colors for 4 players
 * @author dim
 *
 */
public enum PawnColors implements Colors{

	RED,
	YELLOW,
	MAGENTA,
	CYAN,
	BLUE,
	GREEN,
	NULL;
}
