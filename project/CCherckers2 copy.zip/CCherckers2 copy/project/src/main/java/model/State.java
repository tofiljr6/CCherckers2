package model;
/**
 * enum which defines state of field
 * @author dim
 *
 */
public enum State {

	FREE,
	TAKEN;


}
