package model;

public enum Color {
    BLUE,
    RED,
    YELLOW,
    GREEN,
    CYAN,
    MAGENTA,
    NULL;
}
