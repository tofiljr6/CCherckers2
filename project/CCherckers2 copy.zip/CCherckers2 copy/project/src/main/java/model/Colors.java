package model;
/**
 * interface which defines pawn colors
 * @author dim
 *
 */
public interface Colors {

}
