package model;
/**
 * 
 * base class for board models in case if another board is needed
 * @author dim
 *
 */
public class BoardModel {
 
}
