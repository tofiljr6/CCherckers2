package settings;

public class SixArmBoardWinningConditionTEST {
}
