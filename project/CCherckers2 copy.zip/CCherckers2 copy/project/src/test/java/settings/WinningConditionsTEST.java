package settings;

public class WinningConditionsTEST {
}
