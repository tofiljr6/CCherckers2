package model;

import Client2.CCLient;
import Server2.CCPlayer;
import org.junit.Before;
import org.junit.Test;
import settings.SixArmBoard;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import static org.junit.Assert.*;


public class SixArmBoardModelTEST {
    SixArmBoardModel sixArmBoardModel;
    SixArmBoard sixArmBoard;
    CCPlayer ccPlayer;

//    @Before
//    public void init() throws Exception {
//        sixArmBoard = new SixArmBoard();
//        sixArmBoardModel = new SixArmBoardModel(sixArmBoard, 2);
//        ccPlayer = new CCPlayer(sixArmBoardModel, ColorsFor2Players.GREEN, new Socket(59002));
//    }
//
//    @Test
//    public void jumpTest() throws IOException {
//        sixArmBoardModel.jump(16, 4, 15, 5, );
//    }
}
