package model;

public class SixArmBoardPreparerTEST {
}
