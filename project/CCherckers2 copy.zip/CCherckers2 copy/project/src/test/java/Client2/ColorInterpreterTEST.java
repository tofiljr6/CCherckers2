package Client2;

public class ColorInterpreterTEST {
}
