package Server2;

import Client2.CCLient;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.*;

public class CCServerTEST {
//    public CCServer ccServer;
//    public CCLient ccLient1;
//    public CCLient ccLient2;
//
//    @Before
//    public void init() throws Exception {
//        ccServer = new CCServer();
//        ccLient1 = new CCLient("localhost", 2);
//        ccLient2 = new CCLient("localhost", 2);
//    }
//
//    @Test
//    public void isWorking(){
////        assertEquals(true, ccServer.getWorking());
//    }
}
